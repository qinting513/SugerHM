package com.deva.bletest;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

public class ShowFragment extends DummySectionFragment {

	private TextView speedText;
	private TextView extInfoText;
	private RoundProgressBar socProgressBar;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View rootView = inflater.inflate(R.layout.activity_show, container, false);
		speedText=(TextView)rootView.findViewById(R.id.textView_Speed);
		extInfoText=(TextView)rootView.findViewById(R.id.textView_extInfo);
		speedText.setText("0.0");
		speedText.setTextColor(Color.BLUE);
		extInfoText.setText("\n"+getString(R.string.text_waitdatacom));
		socProgressBar = (RoundProgressBar) rootView.findViewById(R.id.progressBar_soc);
		socProgressBar.setMax(100);
		socProgressBar.setProgress(0);
		socProgressBar.setCircleProgressColor(Color.GREEN);
		return rootView;
	}

	@Override
	protected void TranslateInformation(int pos, String info) {
		// TODO Auto-generated method stub
		String outStr="\n"+getString(R.string.text_waitdatacom);
		String[] cmdStr=info.split("=");
		if(cmdStr[0].equals("Z"))
		{
			String[] infoStr=cmdStr[1].split(",");
			if(infoStr.length!=12) return;
			int soc=Integer.parseInt(infoStr[0]);
			if(soc<15)
			{
				socProgressBar.setCircleProgressColor(Color.RED);
			}
			else
			{
				socProgressBar.setCircleProgressColor(Color.GREEN);
			}
			socProgressBar.setProgress(soc);
			speedText.setText(infoStr[1]);
			outStr="\n"+getString(R.string.text_curmile)+infoStr[2]+"Km\n";
			outStr+=getString(R.string.text_resmile)+infoStr[3]+"Km\n";
			outStr+=getString(R.string.text_totalmile)+infoStr[4]+"Km\n";
			outStr+=getString(R.string.text_lastmile)+infoStr[5]+"Km\n";			
			outStr+=getString(R.string.text_consumpermile)+infoStr[6]+"AH\n";
			outStr+=getString(R.string.text_consumcycle)+infoStr[7]+"AH\n";
			outStr+=getString(R.string.text_changecycles)+infoStr[8]+"\n";
			outStr+=getString(R.string.text_batvolt)+infoStr[9]+"V\n";
			outStr+=getString(R.string.text_current)+infoStr[10]+"A\n";
			outStr+=getString(R.string.text_power)+infoStr[11]+"W\n";
			extInfoText.setText(outStr);
		}
		//super.TranslateInformation(pos, info);
	}

}
