package com.deva.bletest;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapter extends FragmentPagerAdapter {
	Context m_context;
	List<Fragment> fragmentList=new ArrayList<Fragment>();

    public SectionsPagerAdapter(FragmentManager fm,Context context) {
        super(fm);
        m_context=context;
        /*
        Fragment fragment=null;
        for(int i=0;i<6;i++)
        {
        	if(i<6)
        	{
        		fragment = new DummySectionFragment();
        	}
        	else if(i==6)
        	{
        		fragment = new SettingFragment();
        	}
        	else if(i==7)
        	{
        		fragment = new Setting2Fragment();
        	}
            Bundle args = new Bundle();
            args.putInt(DummySectionFragment.ARG_SECTION_NUMBER, i+1);
            fragment.setArguments(args);
            fragmentList.add(i,fragment);
        }*/
        
    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a DummySectionFragment (defined as a static inner class
        // below) with the page number as its lone argument.
    	
    	Fragment fragment=null;
        switch(position)
        {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 8:        	
	     	fragment = new DummySectionFragment();
	        break;
        case 0:
        	fragment = new ShowFragment();
        	break;
        case 6:
        	fragment = new SettingFragment();
        	break;
        case 7:
        	fragment = new Setting2Fragment();
        	break;
        }
        Bundle args = new Bundle();
        args.putInt(DummySectionFragment.ARG_SECTION_NUMBER, position + 1);
        fragment.setArguments(args);      
        fragmentList.add(position,fragment);
        return fragment;
        //return fragmentList.get(position);
    }
    public Fragment getFragment(int position){
    
    	return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        // Show 3 total pages.
        return 9;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        Locale l = Locale.getDefault();

        switch (position) {
            case 1:
                return m_context.getString(R.string.title_section1).toUpperCase(l);
            case 0:
                return m_context.getString(R.string.title_section2).toUpperCase(l);
            case 2:
                return m_context.getString(R.string.title_section3).toUpperCase(l);
            case 3:
                return m_context.getString(R.string.title_section4).toUpperCase(l);
            case 4:
                return m_context.getString(R.string.title_section5).toUpperCase(l);
            case 5:
                return m_context.getString(R.string.title_section6).toUpperCase(l);
            case 6:
                return m_context.getString(R.string.title_section7).toUpperCase(l);
            case 7:
                return m_context.getString(R.string.title_section8).toUpperCase(l);
            case 8:
                return m_context.getString(R.string.title_section9).toUpperCase(l);
        }
        return null;
    }
}  
