package com.deva.bletest;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SettingFragment extends DummySectionFragment {

	int supportBatSum=0;
	private Button modifyBtn;
	private TextView titleText;
	private CheckBox batsumChkBox;
	private EditText batsumEditText;
	private EditText initqEditText;
	private CheckBox initqChkBox;
	private EditText polsumEditText;
	private CheckBox polsumChkBox;
	private EditText diawelEditText;
	private CheckBox diawelChkBox;
	private EditText kmwhEditText;
	private CheckBox kmwhChkBox;
	private EditText dymcswEditText;
	private CheckBox dymcswChkBox;
	private EditText dymcpoint1EditText;
	private EditText dymcpoint2EditText;
	private CompoundButton dymcpointChkBox;
	private EditText cgmodEditText;
	private CheckBox cgmodeChkBox;
	private Button recoverBtn;
	private EditText waittimeEditText;
	private CompoundButton waittimeChkBox;
	private EditText lcsocEditText;
	private CheckBox lcsocChkBox;
	private EditText ccfullEditText;
	private CompoundButton ccfullChkBox;
	private Button poweroffBtn;
	private CheckBox checkedQBox;
	private Button forcePowerBtn;
	private EditText authorcodeEditText;
	private CheckBox authorcodeChkBox;
	private Button repairBtn;
	//protected boolean mClickRepairOn=false;
	private MainActivity mainActivity;
	private EditText chkbatqtEditText;
	private CheckBox chkbatqtChkBox;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		// TODO Auto-generated method stub
		mainActivity=(MainActivity) getActivity();
		View rootView = inflater.inflate(R.layout.activity_setting, container, false);
		modifyBtn=(Button)rootView.findViewById(R.id.modifyBtn);
		
		modifyBtn.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
	    		new AlertDialog.Builder((MainActivity) getActivity())
	    		.setTitle(getString(R.string.text_tips))
	    		.setMessage(getString(R.string.text_tipschange))
	    		.setPositiveButton(getString(R.string.text_ok), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				MainActivity activity=(MainActivity) getActivity();
	    				String cmdStr="STB:";
	    			    if(batsumChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(batsumEditText.getText().toString());
	    			    	if(i>supportBatSum || i<1)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_batsumerr))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="A="+batsumEditText.getText().toString()+",";
	    			    }
	    			    if(initqChkBox.isChecked())
	    			    {
	    			    	if(checkedQBox.isChecked())
	    			    	{
	    			    		cmdStr+="M="+initqEditText.getText().toString()+",";
	    			    	}
	    			    	else
	    			    	{
	    			    		cmdStr+="B="+initqEditText.getText().toString()+",";
	    			    	}
	    			    }
	    			    if(dymcswChkBox.isChecked())
	    			    {
	    			    	cmdStr+="C="+dymcswEditText.getText().toString()+",";
	    			    }
	    			    if(dymcpointChkBox.isChecked())
	    			    {
	    			    	cmdStr+="D="+dymcpoint1EditText.getText().toString()+",";
	    			    	cmdStr+="E="+dymcpoint2EditText.getText().toString()+",";
	    			    }
	    			    if(polsumChkBox.isChecked())
	    			    {
	    			    	cmdStr+="F="+polsumEditText.getText().toString()+",";
	    			    }
	    			    if(diawelChkBox.isChecked())
	    			    {
	    			    	cmdStr+="G="+diawelEditText.getText().toString()+",";
	    			    }
	    			    if(kmwhChkBox.isChecked())
	    			    {
	    			    	cmdStr+="H="+kmwhEditText.getText().toString()+",";
	    			    }
	    			    if(cgmodeChkBox.isChecked())
	    			    {
	    			    	cmdStr+="I="+cgmodEditText.getText().toString()+",";
	    			    }
	    			    if(waittimeChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(waittimeEditText.getText().toString());
	    			    	if(i<10)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipswaittime))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="J="+waittimeEditText.getText().toString()+",";
	    			    }
	    			    if(lcsocChkBox.isChecked())
	    			    {
	    			    	float l=Float.parseFloat(lcsocEditText.getText().toString());
	    			    	if(l<50.0 || l>90.0)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipssocrange))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="K="+lcsocEditText.getText().toString()+",";
	    			    }
	    			    if(ccfullChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(ccfullEditText.getText().toString());
	    			    	if(i<3 || i>20)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipsctrange))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="L="+ccfullEditText.getText().toString()+",";
	    			    }
	    			    if(authorcodeChkBox.isChecked())
	    			    {
	    			    	if(activity.g_bSupportPsw)
	    			    	{
	    			    		cmdStr+="N="+authorcodeEditText.getText().toString()+",";
	    			    	}
	    			    }
	    			    if(chkbatqtChkBox.isChecked())
	    			    {
	    			    	cmdStr+="O="+chkbatqtEditText.getText().toString()+",";
	    			    }
	    			    int len=cmdStr.length();
	    			    if(len<128)
	    			    {
	    			    	activity.sendMessageHandle(cmdStr.substring(0,len-1));	    			    	
	    			    }
	    			    else
	    			    {
	    			    	Toast.makeText((MainActivity)getActivity(), "Too long command!!!!", Toast.LENGTH_LONG).show();
	    			    }
	    			}
	    			
	    		})
	    		.setNegativeButton(getString(R.string.text_cancel), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				MainActivity activity=(MainActivity) getActivity();
	    				activity.sendMessageHandle("GTB");
	    			}
	    			
	    		})
	    		.show();
			    
			}
    		
    	});
		recoverBtn=(Button)rootView.findViewById(R.id.recoverBtn);
		recoverBtn.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				//MainActivity mainActivity=(MainActivity) getActivity();
				if(mainActivity.g_bEnableResetBMS)
				{
		    		new AlertDialog.Builder(mainActivity)
		    		.setTitle(getString(R.string.text_waring))
		    		.setMessage(getString(R.string.text_waringtips))
		    		.setPositiveButton(getString(R.string.text_ok), new DialogInterface.OnClickListener(){
	
		    			@Override
		    			public void onClick(DialogInterface arg0, int arg1) {
		    				// TODO Auto-generated method stub
		    				MainActivity activity=(MainActivity) getActivity();
		    				String cmdStr="STM";
		    			    activity.sendMessageHandle(cmdStr);
		    			}
		    		})
		    		.setNegativeButton(getString(R.string.text_cancel), new DialogInterface.OnClickListener(){
	
		    			@Override
		    			public void onClick(DialogInterface arg0, int arg1) {
		    				// TODO Auto-generated method stub
		    				
		    			}
		    			
		    		})
		    		.show();
				}
			    
			}
    		
    	});
		poweroffBtn=(Button)rootView.findViewById(R.id.poweroffBtn);
		poweroffBtn.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				//MainActivity mainActivity=(MainActivity) getActivity();
	    		new AlertDialog.Builder(mainActivity)
	    		.setTitle(getString(R.string.text_waring))
	    		.setMessage(getString(R.string.text_waringshutdown))
	    		.setPositiveButton(getString(R.string.text_ok), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				MainActivity activity=(MainActivity) getActivity();
	    				String cmdStr="STO";
	    			    activity.sendMessageHandle(cmdStr);
	    			}
	    		})
	    		.setNegativeButton(getString(R.string.text_cancel), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				
	    			}
	    			
	    		})
	    		.show();
			}
    	});
		forcePowerBtn=(Button)rootView.findViewById(R.id.forcePowerBtn);
		forcePowerBtn.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				//MainActivity mainActivity=(MainActivity) getActivity();
	    		new AlertDialog.Builder(mainActivity)
	    		.setTitle(getString(R.string.text_waring))
	    		.setMessage(getString(R.string.text_forcetips))
	    		.setPositiveButton(getString(R.string.text_ok), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				MainActivity activity=(MainActivity) getActivity();
	    				String cmdStr="STF";
	    			    activity.sendMessageHandle(cmdStr);
	    			}
	    		})
	    		.setNegativeButton(getString(R.string.text_cancel), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				
	    			}
	    			
	    		})
	    		.show();
			}
    	});
		repairBtn=(Button)rootView.findViewById(R.id.repairModeBtn);
		if(mainActivity.g_bRemariMode)
		{
			repairBtn.setText(R.string.text_quitrepairmode);
		}
		else
		{
			repairBtn.setText(R.string.text_enterrepairmode);
		}
		repairBtn.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				//MainActivity mainActivity=(MainActivity) getActivity();
				if(!mainActivity.g_bRemariMode)
				{
					new AlertDialog.Builder(mainActivity)
		    		.setTitle(getString(R.string.text_waring))
		    		.setMessage(getString(R.string.text_repairtips))
		    		.setPositiveButton(getString(R.string.text_ok), new DialogInterface.OnClickListener(){

		    			@Override
		    			public void onClick(DialogInterface arg0, int arg1) {
		    				// TODO Auto-generated method stub
		    				String cmdStr="STP";
		    				mainActivity.sendMessageHandle(cmdStr);
							repairBtn.setText(R.string.text_quitrepairmode);
							mainActivity.g_bRemariMode=true;
		    			}
		    		})
		    		.setNegativeButton(getString(R.string.text_cancel), new DialogInterface.OnClickListener(){

		    			@Override
		    			public void onClick(DialogInterface arg0, int arg1) {
		    				// TODO Auto-generated method stub
		    				
		    			}
		    			
		    		})
		    		.show();
				}
				else
				{
    				String cmdStr="STR";
    				mainActivity.sendMessageHandle(cmdStr);
					repairBtn.setText(R.string.text_enterrepairmode);
					mainActivity.g_bRemariMode=false;
				}
			}
    	});
		titleText=(TextView)rootView.findViewById(R.id.textView_title);
		batsumEditText=(EditText)rootView.findViewById(R.id.editText_batsum);
		batsumEditText.setEnabled(false);
		batsumChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_batsum);
		batsumChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					batsumEditText.setEnabled(true);
				}
				else
				{
					batsumEditText.setEnabled(false);
				}
			}
			
		});
		initqEditText=(EditText)rootView.findViewById(R.id.editText_initQ);
		initqEditText.setEnabled(false);
		checkedQBox=(CheckBox)rootView.findViewById(R.id.checkBox_checkedQ);
		checkedQBox.setEnabled(false);
		initqChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_initQ);
		initqChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					initqEditText.setEnabled(true);
					checkedQBox.setEnabled(true);
				}
				else
				{
					initqEditText.setEnabled(false);
					checkedQBox.setEnabled(false);
				}
			}
			
		});
		
		cgmodEditText=(EditText)rootView.findViewById(R.id.editText_cgmode);
		cgmodEditText.setEnabled(false);
		cgmodeChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_cgmode);
		cgmodeChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					cgmodEditText.setEnabled(true);
				}
				else
				{
					cgmodEditText.setEnabled(false);
				}
			}
			
		});
		
		lcsocEditText=(EditText)rootView.findViewById(R.id.editText_lcsoc);
		lcsocEditText.setEnabled(false);
		lcsocChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_lcsoc);
		lcsocChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					lcsocEditText.setEnabled(true);
				}
				else
				{
					lcsocEditText.setEnabled(false);
				}
			}
			
		});
		
		ccfullEditText=(EditText)rootView.findViewById(R.id.editText_ccfull);
		ccfullEditText.setEnabled(false);
		ccfullChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_ccfull);
		ccfullChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					ccfullEditText.setEnabled(true);
				}
				else
				{
					ccfullEditText.setEnabled(false);
				}
			}
			
		});
		
		waittimeEditText=(EditText)rootView.findViewById(R.id.editText_waittime);
		waittimeEditText.setEnabled(false);
		waittimeChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_waittime);
		waittimeChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					waittimeEditText.setEnabled(true);
				}
				else
				{
					waittimeEditText.setEnabled(false);
				}
			}
			
		});
		
		authorcodeEditText=(EditText)rootView.findViewById(R.id.editText_authorcode);
		authorcodeEditText.setEnabled(false);
		authorcodeChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_authorcode);
		authorcodeChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					authorcodeEditText.setEnabled(true);
				}
				else
				{
					authorcodeEditText.setEnabled(false);
				}
			}
			
		});
		
		chkbatqtEditText=(EditText)rootView.findViewById(R.id.editText_chkbatqt);
		chkbatqtEditText.setEnabled(false);
		chkbatqtChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_chkbatqt);
		chkbatqtChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					chkbatqtEditText.setEnabled(true);
				}
				else
				{
					chkbatqtEditText.setEnabled(false);
				}
			}
			
		});
		
		polsumEditText=(EditText)rootView.findViewById(R.id.editText_polsum);
		polsumEditText.setEnabled(false);
		polsumChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_polsum);
		polsumChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					polsumEditText.setEnabled(true);
				}
				else
				{
					polsumEditText.setEnabled(false);
				}
			}
			
		});
		
		diawelEditText=(EditText)rootView.findViewById(R.id.editText_diawel);
		diawelEditText.setEnabled(false);
		diawelChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_diawel);
		diawelChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					diawelEditText.setEnabled(true);
				}
				else
				{
					diawelEditText.setEnabled(false);
				}
			}
			
		});
		kmwhEditText=(EditText)rootView.findViewById(R.id.editText_kmwh);
		kmwhEditText.setEnabled(false);
		kmwhChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_kmwh);
		kmwhChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					kmwhEditText.setEnabled(true);
				}
				else
				{
					kmwhEditText.setEnabled(false);
				}
			}
			
		});
		dymcswEditText=(EditText)rootView.findViewById(R.id.editText_dymcsw);
		dymcswEditText.setEnabled(false);
		dymcswChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_dymcsw);
		dymcswChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					dymcswEditText.setEnabled(true);
				}
				else
				{
					dymcswEditText.setEnabled(false);
				}
			}
			
		});
		dymcpoint1EditText=(EditText)rootView.findViewById(R.id.editText_dymcpoint1);
		dymcpoint1EditText.setEnabled(false);
		dymcpoint2EditText=(EditText)rootView.findViewById(R.id.editText_dymcpoint2);
		dymcpoint2EditText.setEnabled(false);
		dymcpointChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_dymcpoint);
		dymcpointChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					dymcpoint1EditText.setEnabled(true);
					dymcpoint2EditText.setEnabled(true);
				}
				else
				{
					dymcpoint1EditText.setEnabled(false);
					dymcpoint2EditText.setEnabled(false);
				}
			}
			
		});
		return rootView;
	}

	protected void TranslateInformation(int pos,String info) {
		// TODO Auto-generated method stub
		MainActivity mainActivity=(MainActivity) getActivity();		
		String[] cmdStr=info.split("=");
		if(cmdStr[0].equals("B"))
		{
			String[] infoStr=cmdStr[1].split(",");
			if(mainActivity.g_bSupportPsw?(infoStr.length<16 && infoStr.length>17):infoStr.length!=15) return;
			supportBatSum=Integer.parseInt(infoStr[0]);
			titleText.setText(getString(R.string.text_bmsversion)+infoStr[13]+"\n"+getString(R.string.text_serialnun)+infoStr[14]+"\n"+getString(R.string.text_maxsum)+infoStr[0]);
			batsumEditText.setText(infoStr[1]);
			initqEditText.setText(infoStr[2]);
			cgmodEditText.setText(infoStr[3]);
			lcsocEditText.setText(infoStr[4]);
			ccfullEditText.setText(infoStr[5]);
			waittimeEditText.setText(infoStr[6]);
			dymcswEditText.setText(infoStr[7]);
			dymcpoint1EditText.setText(infoStr[8]);
			dymcpoint2EditText.setText(infoStr[9]);
			polsumEditText.setText(infoStr[10]);
			diawelEditText.setText(infoStr[11]);
			kmwhEditText.setText(infoStr[12]);
			if(mainActivity.g_bSupportPsw)
			{
				authorcodeEditText.setText(infoStr[15]);
				if(infoStr.length>16)
				{
					chkbatqtEditText.setText(infoStr[16]);
				}
			}
		}
		else if(cmdStr[0].isEmpty())
		{
			if(cmdStr[1].contains("OK"))
			{
				if(mainActivity.g_bSupportPsw)
				{
					if(authorcodeChkBox.isChecked())
					{
						mainActivity.pswString=authorcodeEditText.getText().toString();
					}
				}
				Toast.makeText((MainActivity)getActivity(), getString(R.string.text_changesucess), Toast.LENGTH_LONG).show();
			}
			else if(cmdStr[1].contains("ER"))
			{
				Toast.makeText((MainActivity)getActivity(), getString(R.string.text_changefail), Toast.LENGTH_LONG).show();
			}
		}
	}
}
