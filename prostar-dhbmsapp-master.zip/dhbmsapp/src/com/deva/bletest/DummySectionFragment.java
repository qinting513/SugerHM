package com.deva.bletest;

import android.os.Bundle;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
/**
 * A dummy fragment representing a section of the app, but that simply
 * displays dummy text.
 */
public class DummySectionFragment extends Fragment {
    /**
     * The fragment argument representing the section number for this
     * fragment.
     */
    public static final String ARG_SECTION_NUMBER = "section_number";
	private TextView dummyTextView;
	private TextView qrTextView;
	private TextView accrTextView;
	private TextView accbTextView;
	private int discount=0;
	private int batTestStatus=0;
    
    public DummySectionFragment() {
    	
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
    	View rootView = null;
        int section=getArguments().getInt(ARG_SECTION_NUMBER);
        switch(section)
        {
        case 2:
        case 9:
        case 3:
        case 4:
        case 5:
        	{
        		rootView = inflater.inflate(R.layout.fragment_main_dummy, container, false);
        		dummyTextView = (TextView) rootView.findViewById(R.id.section_label);
        		//dummyTextView.setText(Integer.toString(getArguments().getInt(ARG_SECTION_NUMBER)));             	
        		dummyTextView.setText(getString(R.string.text_waitdatacom));
        		
        	}
        	break;
        case 6:
        	rootView = inflater.inflate(R.layout.fragment_subinfo, container, false);
        	qrTextView=(TextView) rootView.findViewById(R.id.textView_Speed);
        	accrTextView=(TextView) rootView.findViewById(R.id.textView_extInfo);
        	accbTextView=(TextView) rootView.findViewById(R.id.textView3);
        	qrTextView.setText(getString(R.string.text_capdecline));
        	accrTextView.setText(getString(R.string.text_reschange));
        	accbTextView.setText(getString(R.string.text_selfdisc));
        	break;
        }
        return rootView;
    }
    

	public void UpdateView(int position,Message msg)
    {   	
    	TranslateInformation(position,(String)msg.obj);
    }

	protected void TranslateInformation(int pos,String info) {
		// TODO Auto-generated method stub
		int i;
    	View view=getView();
    	if(view==null) return;
		
		String outStr=getString(R.string.text_waitdatacom);
		String[] cmdStr=info.split("=");
		if(pos==1 && cmdStr[0].equals("A"))
		{
			String[] infoStr=cmdStr[1].split(",");
			if(infoStr.length!=32) return;
			outStr=getString(R.string.text_runtime)+infoStr[0]+"   ";
			i=Integer.parseInt(infoStr[28]);
			if(i!=0)
			{
				if(++discount>1) discount=0;
				if(discount==1)
				{
					if((i&0xf000)!=0)
					{
						outStr+=getString(R.string.text_errortips);
					}
					else
					{
						outStr+=getString(R.string.text_alarmtips);
					}
				}
				else
				{
					if((i&0x1)!=0)
					{
						outStr+=getString(R.string.status_lowqe);
					}
					if((i&0x2)!=0)
					{
						outStr+=getString(R.string.status_bmtemphi);				
					}
					if((i&0x4)!=0)
					{
						outStr+=getString(R.string.status_btemplow);				
					}
					if((i&0x8)!=0)
					{
						outStr+=getString(R.string.status_ictemphi);				
					}
					if((i&0x10)!=0)
					{
						outStr+=getString(R.string.status_ictemplow);				
					}
					if((i&0x20)!=0)
					{
						outStr+=getString(R.string.status_tempdiffhi);				
					}
					if((i&0x40)!=0)
					{
						outStr+=getString(R.string.status_mosfail);
					}
					if((i&0x80)!=0)
					{
						outStr+=getString(R.string.status_startabnor);
					}
					if((i&0x100)!=0)
					{
						outStr+=getString(R.string.status_dischgfail);
					}
					if((i&0x200)!=0)
					{
						outStr+=getString(R.string.status_curoutcont);			
					}
					if((i&0x400)!=0)
					{
						outStr+=getString(R.string.status_batfail);
					}
					if((i&0x8000)!=0)
					{
						outStr+="|E1";				
					}
					if((i&0x4000)!=0)
					{
						outStr+="|E2";				
					}
					if((i&0x2000)!=0)
					{
						outStr+="|E3";
					}
					if((i&0x1000)!=0)
					{
						outStr+="|E4";
					}			
				}
			}
			outStr+="\n";
			outStr+=getString(R.string.text_temperature)+"0:"+infoStr[1]+"��    "+getString(R.string.text_temperature)+"1:"+infoStr[2]+"��\n";
			outStr+=getString(R.string.text_temperature)+"2:"+infoStr[3]+"��    "+getString(R.string.text_temperature)+"3:"+infoStr[4]+"��\n";
			outStr+=getString(R.string.text_temperature)+"4:"+infoStr[5]+"��\n";
			outStr+=getString(R.string.text_batvolt)+infoStr[6]+"V\n";
			outStr+=getString(R.string.text_current)+infoStr[7]+"A\n";
			outStr+=getString(R.string.text_power)+infoStr[8]+"W\n";
			outStr+=getString(R.string.text_totalcap)+infoStr[9]+"AH\n";
			outStr+=getString(R.string.text_availeq)+infoStr[10]+"AH\n";
			outStr+=getString(R.string.text_usedeq)+infoStr[11]+"AH\n";
			if(infoStr.length<32)
			{
				outStr+=getString(R.string.text_circlecap)+infoStr[29]+"AH\n";
			}
			else
			{
				outStr+=getString(R.string.text_totalusedeq)+infoStr[29]+"AH\n";
				outStr+=getString(R.string.text_totalchargeq)+infoStr[31]+"AH\n";
			}
			outStr+="SOC:"+infoStr[12]+"%\n";
			outStr+=getString(R.string.text_avvolt)+infoStr[13]+"V\n";
			outStr+=getString(R.string.text_maxvolt)+infoStr[14]+"V\n";
			outStr+=getString(R.string.text_minvolt)+infoStr[15]+"V\n";
			outStr+=getString(R.string.text_totalvolt)+infoStr[16]+"V\n";
			outStr+=getString(R.string.text_diffvolt)+infoStr[17]+"V\n";
			i=Integer.parseInt(infoStr[18]);
			switch(i)
			{
			case 0:
				outStr+=getString(R.string.text_stawait)+"\n";
				break;
			case 1:
				outStr+=getString(R.string.text_stacharge)+getString(R.string.text_timeremain)+infoStr[30]+"\n";
				break;
			case 2:
				outStr+=getString(R.string.text_stadisc)+getString(R.string.text_timeremain)+infoStr[30]+"\n";
				break;
			case 3:
				outStr+=getString(R.string.text_staprotect)+"\n";
				break;
			case 10:
				outStr+=getString(R.string.text_repairing)+"\n";
				MainActivity mainActivity=(MainActivity) getActivity();
				mainActivity.g_bRemariMode=true;
				break;
			default:
				outStr+=getString(R.string.text_staerror)+getString(R.string.text_errcode)+infoStr[27]+"\n";
				break;
			}
			i=Integer.parseInt(infoStr[19]);
			if(i==0)
			{
				outStr+=getString(R.string.text_ccmosoff);
			}
			else
			{
				outStr+=getString(R.string.text_ccmoson);
			}
			i=Integer.parseInt(infoStr[20]);
			if(i==0)
			{
				outStr+=getString(R.string.text_dcmosoff)+"\n";
			}
			else
			{
				outStr+=getString(R.string.text_dcmoson)+"\n";
			}
			i=Integer.parseInt(infoStr[21]);
			if(i==0)
			{
				outStr+=getString(R.string.text_balanceoff);
			}
			else
			{
				outStr+=getString(R.string.text_balanceon);
			}
			i=Integer.parseInt(infoStr[22]);
			if(i>0)
			{
				outStr+=getString(R.string.text_balancemode)+i+"\n";
			}
			else
			{
				outStr+="\n";
			}

			i=Integer.parseInt(infoStr[23]);
			outStr+=getString(R.string.text_initcapchksta);
			if(i==0)
			{
				outStr+=getString(R.string.text_nocheck)+"\n";
			}
			else if(i==1)
			{
				outStr+=getString(R.string.text_checkin)+"\n";
			}
			else
			{
				outStr+=getString(R.string.text_checkout)+"\n";
			}
			i=Integer.parseInt(infoStr[24]);
			outStr+=getString(R.string.text_dyncheckedsta);
			if(i==0)
			{
				outStr+=getString(R.string.text_nocheck)+"\n";
			}
			else if(i==1)
			{
				outStr+=getString(R.string.text_checkin)+"\n";
			}
			else
			{
				outStr+=getString(R.string.text_checkout)+"\n";
			}
			outStr+=getString(R.string.text_dyncheck1)+infoStr[25]+"\n";
			outStr+=getString(R.string.text_dyncheck2)+infoStr[26]+"\n";
			dummyTextView.setText(outStr);
		}
		else if(pos==8 && cmdStr[0].equals("X"))
		{
			//
			outStr=getString(R.string.text_errorrec)+"\n";			
			if(cmdStr.length>1)
			{
				String[] infoStr=cmdStr[1].split(",");
				for(i=0;i<infoStr.length;i++)
				{
					outStr+=String.format("%02d)",i+1)+infoStr[i]+"\n";
				}
			}
			dummyTextView.setText(outStr);
		}
		else if(pos==2 && cmdStr[0].equals("C"))
		{
			//
			outStr="";			
			if(cmdStr.length>1)
			{
				String[] infoStr=cmdStr[1].split(",");
				for(i=0;i<infoStr.length;i++)
				{
					if(i%2==0)
					{
						outStr+=String.format("BAT%02d : ",i+1)+infoStr[i]+"V      ";
					}
					else
					{
						outStr+=String.format("BAT%02d : ",i+1)+infoStr[i]+"V\n";
					}
				}
			}
			dummyTextView.setText(outStr);
		}
		else if(pos==3 && cmdStr[0].equals("F"))
		{
			//
			outStr="";			
			if(cmdStr.length>1)
			{
				String[] infoStr=cmdStr[1].split(",");
				for(i=0;i<infoStr.length;i++)
				{
					if(i%2==0)
					{
						outStr+=String.format("BAT%02d : ",i+1)+infoStr[i]+"AH      ";
					}
					else
					{
						outStr+=String.format("BAT%02d : ",i+1)+infoStr[i]+"AH\n";
					}
				}
			}
			dummyTextView.setText(outStr);
		}
		else if(pos==4 && cmdStr[0].equals("E"))
		{
			//
			outStr="";			
			if(cmdStr.length>1)
			{
				String[] infoStr=cmdStr[1].split(",");
				for(i=0;i<infoStr.length;i++)
				{
					if(i%2==0)
					{
						outStr+=String.format("BAT%02d : ",i+1)+infoStr[i]+"AH      ";
					}
					else
					{
						outStr+=String.format("BAT%02d : ",i+1)+infoStr[i]+"AH\n";
					}
				}
			}
			dummyTextView.setText(outStr);
		}
		else if(pos==5)
		{ 
			if(cmdStr[0].equals("S"))
			{
				if(cmdStr.length>1)
				{
					String[] infoStr=cmdStr[1].split(",");
					if(infoStr.length!=3) return;
					batTestStatus=Integer.parseInt(infoStr[2]);
				}
			}
			if(cmdStr[0].equals("H"))
			{
				//
				outStr=getString(R.string.text_capdecline)+"\n";	
				if(cmdStr.length>1)
				{
					String[] infoStr=cmdStr[1].split(",");
					for(i=0;i<infoStr.length;i++)
					{
						if(((batTestStatus>>i)&0x1)==0)
						{
							outStr+=String.format("BAT%02d: ",i+1)+infoStr[i]+"\n";							
						}
						else
						{
							outStr+=String.format("*BAT%02d: ",i+1)+infoStr[i]+"\n";	
						}
					}
				}
				qrTextView.setText(outStr);
			}
			if(cmdStr[0].equals("G"))
			{
				//
				outStr=getString(R.string.text_reschange)+"\n";	
				if(cmdStr.length>1)
				{
					String[] infoStr=cmdStr[1].split(",");
					for(i=0;i<infoStr.length;i++)
					{
						outStr+=infoStr[i]+"\n";
					}
				}
				accrTextView.setText(outStr);
			}
			if(cmdStr[0].equals("I"))
			{
				//
				outStr=getString(R.string.text_selfdisc)+"\n";	
				if(cmdStr.length>1)
				{
					String[] infoStr=cmdStr[1].split(",");
					for(i=0;i<infoStr.length;i++)
					{
						outStr+=infoStr[i]+"\n";
					}
				}
				accbTextView.setText(outStr);
			}
		}
	}

	@Override
	public void onPause() {
		// TODO Auto-generated method stub
		Log.d("===DummySectionFragment Section("+getArguments().getInt(ARG_SECTION_NUMBER)+")========","OnPause");
		super.onPause();
	}

	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		Log.d("===DummySectionFragment Section("+getArguments().getInt(ARG_SECTION_NUMBER)+")========","OnResume");
		super.onResume();
	}
    
}
