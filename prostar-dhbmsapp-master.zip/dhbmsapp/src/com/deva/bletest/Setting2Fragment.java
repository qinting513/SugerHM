package com.deva.bletest;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Setting2Fragment extends DummySectionFragment {

	private Button modifyBtn;
	private EditText param1EditText;
	private CheckBox param1ChkBox;
	private EditText param2EditText;
	private CheckBox param2ChkBox;
	private EditText param3EditText;
	private CheckBox param3ChkBox;
	private EditText param4EditText;
	private CheckBox param4ChkBox;
	private EditText param5EditText;
	private CheckBox param5ChkBox;
	private EditText param6EditText;
	private CheckBox param6ChkBox;
	private EditText param7EditText;
	private CheckBox param7ChkBox;
	private EditText param8EditText;
	private CheckBox param8ChkBox;
	private EditText param9EditText;
	private CheckBox param9ChkBox;
	private EditText param10EditText;
	private CheckBox param10ChkBox;
	private EditText param11EditText;
	private CheckBox param11ChkBox;
	private EditText param12EditText;
	private CheckBox param12ChkBox;
	private EditText param13EditText;
	private CheckBox param13ChkBox;
	private EditText param14EditText;
	private CheckBox param14ChkBox;
	private EditText param15EditText;
	private CheckBox param15ChkBox;
	private EditText param16EditText;
	private CheckBox param16ChkBox;
	private EditText param17EditText;
	private CheckBox param17ChkBox;
	private EditText param18EditText;
	private CheckBox param18ChkBox;
	private EditText param19EditText;
	private CompoundButton param19ChkBox;
	private EditText param20EditText;
	private CompoundButton param20ChkBox;
	private EditText param21EditText;
	private CompoundButton param21ChkBox;
	private EditText param22EditText;
	private CheckBox param22ChkBox;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View rootView = inflater.inflate(R.layout.activity_setting2, container, false);
		modifyBtn=(Button)rootView.findViewById(R.id.parammodifyBtn);
		
		modifyBtn.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
	    		new AlertDialog.Builder((MainActivity) getActivity())
	    		.setTitle(getString(R.string.text_tips))
	    		.setMessage(getString(R.string.text_tipschange))
	    		.setPositiveButton(getString(R.string.text_ok), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				MainActivity activity=(MainActivity) getActivity();
	    				String cmdStr="STY:";
	    			    if(param1ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="A="+param1EditText.getText().toString()+",";
	    			    }
	    			    if(param2ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="B="+param2EditText.getText().toString()+",";
	    			    }
	    			    if(param3ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="C="+param3EditText.getText().toString()+",";
	    			    }
	    			    if(param4ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="D="+param4EditText.getText().toString()+",";
	    			    }
	    			    if(param5ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="E="+param5EditText.getText().toString()+",";
	    			    }
	    			    if(param6ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="F="+param6EditText.getText().toString()+",";
	    			    }
	    			    if(param7ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="G="+param7EditText.getText().toString()+",";
	    			    }
	    			    if(param8ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="H="+param8EditText.getText().toString()+",";
	    			    }
	    			    if(param9ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="I="+param9EditText.getText().toString()+",";
	    			    }
	    			    if(param10ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="J="+param10EditText.getText().toString()+",";
	    			    }
	    			    if(param11ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="K="+param11EditText.getText().toString()+",";
	    			    }
	    			    if(param12ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="L="+param12EditText.getText().toString()+",";
	    			    }
	    			    if(param13ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="M="+param13EditText.getText().toString()+",";
	    			    }
	    			    if(param14ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="N="+param14EditText.getText().toString()+",";
	    			    }
	    			    if(param15ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="O="+param15EditText.getText().toString()+",";
	    			    }
	    			    if(param16ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="P="+param16EditText.getText().toString()+",";
	    			    }
	    			    if(param17ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="Q="+param17EditText.getText().toString()+",";
	    			    }
	    			    if(param18ChkBox.isChecked())
	    			    {
	    			    	cmdStr+="R="+param18EditText.getText().toString()+",";
	    			    }
	    			    if(param19ChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(param19EditText.getText().toString());
	    			    	if(i<1 || i>30)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipsrange))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="S="+param19EditText.getText().toString()+",";
	    			    }
	    			    if(param20ChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(param20EditText.getText().toString());
	    			    	if(i<1 || i>30)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipsrange))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="T="+param20EditText.getText().toString()+",";
	    			    }
	    			    if(param21ChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(param21EditText.getText().toString());
	    			    	if(i<1 || i>30)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipsrange))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="U="+param21EditText.getText().toString()+",";
	    			    }
	    			    if(param22ChkBox.isChecked())
	    			    {
	    			    	int i=Integer.parseInt(param22EditText.getText().toString());
	    			    	if(i<1 || i>30)
	    			    	{
	    			    		new AlertDialog.Builder(activity)
	    			    		.setTitle(getString(R.string.text_tipserror))
	    			    		.setMessage(getString(R.string.text_tipsrange))
	    			    		.setPositiveButton(getString(R.string.text_ok), null)
	    			    		.show();
	    			    		return ;
	    			    	}
	    			    	cmdStr+="V="+param22EditText.getText().toString()+",";
	    			    }
	    			    int len=cmdStr.length();
	    			    activity.sendMessageHandle(cmdStr.substring(0,len-1));
	    			}
	    			
	    		})
	    		.setNegativeButton(getString(R.string.text_cancel), new DialogInterface.OnClickListener(){

	    			@Override
	    			public void onClick(DialogInterface arg0, int arg1) {
	    				// TODO Auto-generated method stub
	    				MainActivity activity=(MainActivity) getActivity();
	    				activity.sendMessageHandle("GTY");
	    			}
	    			
	    		})
	    		.show();
			    
			}
    		
    	});
		
		param1EditText=(EditText)rootView.findViewById(R.id.editText_param1);
		param1EditText.setEnabled(false);
		param1ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param1);
		param1ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param1EditText.setEnabled(true);
				}
				else
				{
					param1EditText.setEnabled(false);
				}
			}
			
		});
		param2EditText=(EditText)rootView.findViewById(R.id.editText_param2);
		param2EditText.setEnabled(false);
		param2ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param2);
		param2ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param2EditText.setEnabled(true);
				}
				else
				{
					param2EditText.setEnabled(false);
				}
			}
			
		});
		param3EditText=(EditText)rootView.findViewById(R.id.editText_param3);
		param3EditText.setEnabled(false);
		param3ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param3);
		param3ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param3EditText.setEnabled(true);
				}
				else
				{
					param3EditText.setEnabled(false);
				}
			}
			
		});
		param4EditText=(EditText)rootView.findViewById(R.id.editText_param4);
		param4EditText.setEnabled(false);
		param4ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param4);
		param4ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param4EditText.setEnabled(true);
				}
				else
				{
					param4EditText.setEnabled(false);
				}
			}
			
		});
		param5EditText=(EditText)rootView.findViewById(R.id.editText_param5);
		param5EditText.setEnabled(false);
		param5ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param5);
		param5ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param5EditText.setEnabled(true);
				}
				else
				{
					param5EditText.setEnabled(false);
				}
			}
			
		});
		param6EditText=(EditText)rootView.findViewById(R.id.editText_param6);
		param6EditText.setEnabled(false);
		param6ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param6);
		param6ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param6EditText.setEnabled(true);
				}
				else
				{
					param6EditText.setEnabled(false);
				}
			}
			
		});
		param7EditText=(EditText)rootView.findViewById(R.id.editText_param7);
		param7EditText.setEnabled(false);
		param7ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param7);
		param7ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param7EditText.setEnabled(true);
				}
				else
				{
					param7EditText.setEnabled(false);
				}
			}
			
		});
		param8EditText=(EditText)rootView.findViewById(R.id.editText_param8);
		param8EditText.setEnabled(false);
		param8ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param8);
		param8ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param8EditText.setEnabled(true);
				}
				else
				{
					param8EditText.setEnabled(false);
				}
			}
			
		});
		param9EditText=(EditText)rootView.findViewById(R.id.editText_param9);
		param9EditText.setEnabled(false);
		param9ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param9);
		param9ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param9EditText.setEnabled(true);
				}
				else
				{
					param9EditText.setEnabled(false);
				}
			}
			
		});
		param10EditText=(EditText)rootView.findViewById(R.id.editText_param10);
		param10EditText.setEnabled(false);
		param10ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param10);
		param10ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param10EditText.setEnabled(true);
				}
				else
				{
					param10EditText.setEnabled(false);
				}
			}
			
		});
		param11EditText=(EditText)rootView.findViewById(R.id.editText_param11);
		param11EditText.setEnabled(false);
		param11ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param11);
		param11ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param11EditText.setEnabled(true);
				}
				else
				{
					param11EditText.setEnabled(false);
				}
			}
			
		});
		param12EditText=(EditText)rootView.findViewById(R.id.editText_param12);
		param12EditText.setEnabled(false);
		param12ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param12);
		param12ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param12EditText.setEnabled(true);
				}
				else
				{
					param12EditText.setEnabled(false);
				}
			}
			
		});
		param13EditText=(EditText)rootView.findViewById(R.id.editText_param13);
		param13EditText.setEnabled(false);
		param13ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param13);
		param13ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param13EditText.setEnabled(true);
				}
				else
				{
					param13EditText.setEnabled(false);
				}
			}
			
		});
		param14EditText=(EditText)rootView.findViewById(R.id.editText_param14);
		param14EditText.setEnabled(false);
		param14ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param14);
		param14ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param14EditText.setEnabled(true);
				}
				else
				{
					param14EditText.setEnabled(false);
				}
			}
			
		});
		param15EditText=(EditText)rootView.findViewById(R.id.editText_param15);
		param15EditText.setEnabled(false);
		param15ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param15);
		param15ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param15EditText.setEnabled(true);
				}
				else
				{
					param15EditText.setEnabled(false);
				}
			}
			
		});
		param16EditText=(EditText)rootView.findViewById(R.id.editText_param16);
		param16EditText.setEnabled(false);
		param16ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param16);
		param16ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param16EditText.setEnabled(true);
				}
				else
				{
					param16EditText.setEnabled(false);
				}
			}
			
		});
		param17EditText=(EditText)rootView.findViewById(R.id.editText_param17);
		param17EditText.setEnabled(false);
		param17ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param17);
		param17ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param17EditText.setEnabled(true);
				}
				else
				{
					param17EditText.setEnabled(false);
				}
			}
			
		});
		param18EditText=(EditText)rootView.findViewById(R.id.editText_param18);
		param18EditText.setEnabled(false);
		param18ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param18);
		param18ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param18EditText.setEnabled(true);
				}
				else
				{
					param18EditText.setEnabled(false);
				}
			}
			
		});
		param19EditText=(EditText)rootView.findViewById(R.id.editText_param19);
		param19EditText.setEnabled(false);
		param19ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param19);
		param19ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param19EditText.setEnabled(true);
				}
				else
				{
					param19EditText.setEnabled(false);
				}
			}
			
		});
		param20EditText=(EditText)rootView.findViewById(R.id.editText_param20);
		param20EditText.setEnabled(false);
		param20ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param20);
		param20ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param20EditText.setEnabled(true);
				}
				else
				{
					param20EditText.setEnabled(false);
				}
			}
			
		});
		param21EditText=(EditText)rootView.findViewById(R.id.editText_param21);
		param21EditText.setEnabled(false);
		param21ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param21);
		param21ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param21EditText.setEnabled(true);
				}
				else
				{
					param21EditText.setEnabled(false);
				}
			}
			
		});
		param22EditText=(EditText)rootView.findViewById(R.id.editText_param22);
		param22EditText.setEnabled(false);
		param22ChkBox=(CheckBox)rootView.findViewById(R.id.checkBox_param22);
		param22ChkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub
				if(arg1)
				{
					//ѡ��
					param22EditText.setEnabled(true);
				}
				else
				{
					param22EditText.setEnabled(false);
				}
			}
			
		});
		return rootView;
	}
	@SuppressLint("NewApi") protected void TranslateInformation(int pos,String info) {
		// TODO Auto-generated method stub
		String[] cmdStr=info.split("=");
		if(cmdStr[0].equals("Y"))
		{
			String[] infoStr=cmdStr[1].split(",");
			if(infoStr.length!=22) return;
			param1EditText.setText(infoStr[0]);
			param2EditText.setText(infoStr[1]);
			param3EditText.setText(infoStr[2]);
			param4EditText.setText(infoStr[3]);
			param5EditText.setText(infoStr[4]);
			param6EditText.setText(infoStr[5]);
			param7EditText.setText(infoStr[6]);
			param8EditText.setText(infoStr[7]);
			param9EditText.setText(infoStr[8]);
			param10EditText.setText(infoStr[9]);
			param11EditText.setText(infoStr[10]);
			param12EditText.setText(infoStr[11]);
			param13EditText.setText(infoStr[12]);
			param14EditText.setText(infoStr[13]);
			param15EditText.setText(infoStr[14]);
			param16EditText.setText(infoStr[15]);
			param17EditText.setText(infoStr[16]);
			param18EditText.setText(infoStr[17]);
			param19EditText.setText(infoStr[18]);
			param20EditText.setText(infoStr[19]);
			param21EditText.setText(infoStr[20]);
			param22EditText.setText(infoStr[21]);
		}
		else if(cmdStr[0].isEmpty())
		{
			if(cmdStr[1].contains("OK"))
			{
				Toast.makeText((MainActivity)getActivity(), getString(R.string.text_changesucess), Toast.LENGTH_LONG).show();
			}
			else if(cmdStr[1].contains("ER"))
			{
				Toast.makeText((MainActivity)getActivity(), getString(R.string.text_changefail), Toast.LENGTH_LONG).show();
			}
		}
	}
}
