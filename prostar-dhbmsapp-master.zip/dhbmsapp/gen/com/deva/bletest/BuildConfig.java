/** Automatically generated file. DO NOT MODIFY */
package com.deva.bletest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}